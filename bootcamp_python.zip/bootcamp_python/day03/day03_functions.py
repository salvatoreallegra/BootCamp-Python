#--------------------------
#functions.py
#-------------------------

def greet(name):
    return f"Hello, {name}!"

def add(a, b):
    return a + b

print(greet("Sal"))
print("Sum of 3 and 5 is:", add(3, 5))